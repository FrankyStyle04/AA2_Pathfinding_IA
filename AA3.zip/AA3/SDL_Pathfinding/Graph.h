﻿#pragma once
#include <vector>
#include "Node.h"

class Graph
{
private:
    std::vector< std::vector<Node*> > weights;
    
};
